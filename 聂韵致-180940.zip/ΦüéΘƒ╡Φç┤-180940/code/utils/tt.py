# from utils.dataset import *
# from train import args
import matplotlib.pyplot as plt

# dataset = TuSimpleDataset(args, phase='train', transform=transforms.Compose([RandomShift(args),
#                                                                                  RandomHorizontalFlip(args),
#                                                                                  RandomRotateScale(args),
#                                                                                  PostProcess(args)]))
#
# loader = DataLoader(dataset, batch_size=32, collate_fn=collect_fn)
# slicing_line_y = np.arange(0, 288, 288/72)
# for iddx, batch in enumerate(loader):
#     imgs, lanes = batch['img'], batch['coords']
#     for j, (img, lane) in enumerate(zip(imgs, lanes)):
#         img = img.numpy()
#         for la in lane:
#             for x, y in zip(la, slicing_line_y):
#                 cv2.circle(img, (int(x), int(y)), radius=2, color=(255, 255, 255), thickness=-1)
#             if max(la) > 0:
#                 print(iddx, j)
#             else:
#                 print('error', iddx, j)
#                 print(lane)
#         cv2.imwrite('../dataset_image/'+str(iddx)+'-'+str(j)+'.png', img)
    # plt.imshow(np.array(img, np.uint8))
    # plt.show()

# img = cv2.imread('../temp_image/ppt8.png')
# m = cv2.getRotationMatrix2D((img.shape[1] // 2, img.shape[0] // 2), 6, 1)
# img = cv2.warpAffine(img, m, (img.shape[1], img.shape[0]))
# plt.imshow(img)
# plt.show()

# files = []
# for file in os.listdir(args.root):
#     if os.path.isfile(os.path.join(args.root, file)) and 'test' in file and file.endswith('.json'):  # 是满足条件的json文件
#         print(file)
#         f = open(os.path.join(args.root, file))
#         for line in f.readlines():
#             files.extend([json.loads(line)])
#         print(len(files))
#         print(files[0:5])
#         files = []

# import numpy as np
#
# lane_infos = [(0.6, np.array([400,300,200])),
#               (0.5, np.array([200,200,200])),
#               (0.9, np.array([310,410,510])),
#               (0.8, np.array([300,400,500]))]
#
# def cal_distance(lane1, lane2):
#     distance = np.sum(np.abs(lane1 - lane2)) / (3)
#     return distance
#
# # (ldr_index, angle, feature_index, classification_score, lane)
# def NMS(lane_infos):
#     lane_infos.sort(key=lambda x: x[0], reverse=True)
#     print(lane_infos)
#     k = 0
#     while k < (len(lane_infos) - 1):
#         pop_list = []
#         for i in range(k + 1, len(lane_infos)):
#             if cal_distance(lane_infos[k][-1], lane_infos[i][-1]) <= 20.:
#                 pop_list.append(i)
#         print(k, pop_list)
#         for pop_i in pop_list[::-1]:
#             lane_infos.pop(pop_i)
#         k += 1
#     return lane_infos
#
# print(NMS(lane_infos))

# save train data(train.py)
# slicing_line_y = np.arange(0, 288, 4)
# for i, lane_batch in zip(range(args.batch_size), lanes_batch):
#     img_ = np.array(img[i].numpy(), np.uint8)
#     for xs in lane_batch:
#         for x, y in zip(xs, slicing_line_y):
#             cv2.circle(img_, (int(x), int(y)), 1, (255, 0, 255), 1)
#     img_ = img_[:, :, [2, 1, 0]]
#     cv2.imwrite('./temp_image/TESTDATA-NO.' + str(idx) + '_' + str(i) + '.png', img_)
    # plt.imshow(img_)
    # plt.show()

# import matplotlib.pyplot as plt
# import numpy as np
# from train import args
# import cv2
# lanes = [[-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 325.3000649777636, 320.4619016630936, 316.3493177334823, 315.43586743368985, 317.19818062261953, 319.460732063349, 321.5481914522468, 323.9481914522468, 326.3481914522468, 328.74819145224683, 331.1481914522468, 334.41069957446723, 338.24821311150134, 342.24821311150134, 346.24821311150134, 350.24821311150134, 354.2106562559582, 357.81065625595824, 361.7982239411286, 365.79822394112864, 369.79822394112864, 373.79822394112864, 377.79822394112864, 381.79822394112864, 385.79822394112864, 389.79822394112864, 393.7982239411286, 397.4105696189401, 401.3482347707558, 405.3482347707558, 409.3482347707559, 413.3482347707559, 417.3482347707558, 421.3482347707558, 425.3482347707559, 429.3482347707559, 433.3482347707559, 437.010482981922, 440.8982456003831, 444.8982456003831, 448.8982456003831, 452.8982456003832, 456.8982456003832, 460.8982456003831, 464.8982456003832, 468.8982456003832], [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 261.96469570692796, 251.16469570692792, 240.83954950695983, 232.33905134410566, 225.53905134410564, 218.73905134410566, 211.93905134410565, 205.13905134410567, 198.33905134410566, 191.53905134410564, 184.73905134410566, 177.93905134410565, 171.70162444408965, 165.96408924780104, 160.05163527371693, 154.41407841817377, 148.4140784181738, 142.8016461033442, 136.8640675885465, 131.15165693297146, 125.3140567589193, 119.50166776259874, 113.76404592929198, 107.851678592226, 102.21403509966473, 96.21403509966476, 90.60168942185325, 84.66402427003749, 78.95170025148055, 73.1140134404102, 67.30171108110778, 61.56400261078297, 55.651721910735084, 50.01399178115565, 44.01399178115568, 38.40173274036225, 32.46398095152835, 26.751743569989564, 20.913970121901166, 15.101754399616842, 9.36395929227384, 3.451765229244094, -2, -2, -2], [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 362.75984403391334, 369.195581512076, 378.4704353121079, 388.6327485010376, 399.4327485010376, 410.23274850103763, 421.03274850103764, 431.8327485010376, 443.02022954918993, 453.8827376714104, 464.68273767141034, 475.4827376714103, 486.47026203807167, 497.5327268417831, 508.3327268417831, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 209.2054581321414, 190.0677063433075, 171.50513324332343, 152.91769551368014, 134.25514407295066, 116.03006285074623, 98.5424735063213, 82.14247350632138, 65.35499245816897, 48.89248433594851, 32.20498162854178, 15.6424951655758, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2]]
# img = np.zeros((args.height, args.width, 3), np.uint8)
# slicing_line_y = np.arange(0, args.height, args.height / args.slice)
# for lane in lanes:
#     for xs, ys in zip(lane, slicing_line_y):
#         print(xs, ys)
#         cv2.circle(img, (int(xs), int(ys)), 3, (255, 255, 0), -1)
# pos_indexs = [[(16, 4), (17, 3), (10, 5)], [(27, 3), (28, 3)], [(10, 5), (11, 4)]]
# from utils.dataset import *
# from metric import cal_Loss, generate_anchor_x_shift
# anchor_x_shift_l = generate_anchor_x_shift([kl, kd, kr], 0, args)  # (18, 72, 6)
# anchor_x_shift_d = generate_anchor_x_shift([kl, kd, kr], 1, args)  # (30, 72, 15)
# anchor_x_shift_r = generate_anchor_x_shift([kl, kd, kr], 2, args)  # (18, 72, 6)
# for pos_index in pos_indexs[0]:
#     y_index, angle = pos_index
#     lane = anchor_x_shift_l[y_index, :, angle]
#     for xs, ys in zip(lane, slicing_line_y):
#         cv2.circle(img, (int(xs), int(ys)), 3, (255, 0, 0), -1)
# for pos_index in pos_indexs[1]:
#     y_index, angle = pos_index
#     lane = anchor_x_shift_d[y_index, :, angle]
#     for xs, ys in zip(lane, slicing_line_y):
#         cv2.circle(img, (int(xs), int(ys)), 3, (255, 0, 0), -1)
# for pos_index in pos_indexs[2]:
#     y_index, angle = pos_index
#     lane = anchor_x_shift_r[y_index, :, angle]
#     for xs, ys in zip(lane, slicing_line_y):
#         cv2.circle(img, (int(xs), int(ys)), 3, (255, 0, 0), -1)
# cv2.imwrite('./temp_image/tt.png', img)
# plt.imshow(img)
# plt.show()

# import os, json
# root = '/home/share/samples/tusimple/'
# train_path1 = os.path.join(root, 'label_data_0531.json')
# train_path2 = os.path.join(root, 'label_data_0313.json')
# train_path3 = os.path.join(root, 'label_data_0601.json')
# train_names = []
# for lanes in open(train_path1).readlines():
#     lane = json.loads(lanes)
#     train_names.append(lane['raw_file'])
# for lanes in open(train_path2).readlines():
#     lane = json.loads(lanes)
#     train_names.append(lane['raw_file'])
# for lanes in open(train_path3).readlines():
#     lane = json.loads(lanes)
#     train_names.append(lane['raw_file'])
# print(len(train_names))
# test_name = os.path.join(root, 'test_gt.json')
# for lanes in open(test_name).readlines():
#     lane = json.loads(lanes)
#     train_names.append(lane['raw_file'])
# print(len(set(train_names)))

# import os, json
# root = '/home/share/samples/tusimple/'
# test_name = os.path.join(root, 'test_gt.json')
# test_lanes = []
# h_samples = []
# for lanes in open(test_name).readlines():
#     lane = json.loads(lanes)
#     test_lanes.append(lane['lanes'])
#     h_samples.append(lane['h_samples'])
#
# from train import args
# import numpy as np
# import cv2
# img = np.zeros((int(args.height*2.5), int(args.width*2.5), 3), np.uint8)
# for xs, ys in zip(test_lanes, h_samples):
#     for j in range(len(xs)):
#         for i in range(len(ys)-1):
#             if xs[j][i] >= 0 and xs[j][i+1] >= 0:
#                 cv2.line(img, (xs[j][i], ys[i]), (xs[j][i+1], ys[i+1]), (255, 255, 255), 1, 8)
# cv2.imwrite('../temp_image/All_label_draw.png', img)
# plt.imshow(img)
# plt.show()

# from train import args
# from utils.dataset import *
# dataset = UISEEDataset(args)
# dataloader = DataLoader(dataset, batch_size=1, num_workers=0)
# for batch in dataloader:
#     img = batch['img']
#     print(img.shape)
#     plt.imshow(img[0].int().numpy())
#     plt.show()
#     break

# def expand_lane(lane, length, end_index):
#     while end_index-1 < 72:
#         if end_index-1 == 71:
#             if lane[end_index-1] < 0 or lane[end_index-1] >= 512:
#                 end_index -= 1
#             else:
#                 break
#         else:
#             if lane[end_index-1] < 0 or lane[end_index-1] >= 512:
#                 end_index -= 1
#             else:
#                 if lane[end_index] < 0 or lane[end_index] >= 512:
#                     break
#                 else:
#                     lane[end_index] = lane[end_index-1] + (lane[end_index-1] - lane[end_index-2])
#                     end_index += 1
#
#     start_index = end_index - int(length)
#     return lane, start_index, end_index
#
# print(expand_lane([0]*(72-7)+[480,490,500,510,0,0,0], 6, 68))


# import json
# import os
# import evaluate
# gt = [json.loads(line) for line in open(os.path.join('/home/share/samples/tusimple', 'test_gt.json')).readlines()]
# pred = [json.loads(line) for line in open(os.path.join('/home/xhz/workspace/line_cnn_master/new_code', 'pred_lanes.json')).readlines()]
# bad_pred_id = []
# for i in range(len(pred)):
#     # if i == 11:
#     #     print(gt[i]['lanes'])
#     gt_lanes = gt[i]['lanes']
#     y_samples = gt[i]['h_samples']
#     pred_lanes = pred[i]['lanes']
#     acc, FP, FN = evaluate.LaneEval.bench(pred_lanes, gt_lanes, y_samples, 0)
#     if acc < 0.9:
#         print('pic-NO.', i)
#         print(acc, FP, FN)
#         bad_pred_id.append(i)
#     break
# print(bad_pred_id)

# with open('../supplement_lane.txt', 'r+') as file:
#     items = file.readlines()
#     count = 0
#     lanes_info = []
#     for item in items:
#         if item == '*******************\n':
#             count += 1
#         else:
#             i, j, y_index, angle, dis = item.split(',')
#             j = int(j.strip())
#             y_index = int(y_index.strip())
#             angle = int(angle.strip())
#             dis = dis.strip()[:5]
#             lanes_info.append((j, y_index, angle, dis))
#         if count == 3626:
#             break
#     from collections import Counter
#     js = [lane[0] for lane in lanes_info]
#     counter = Counter(js)
#
#     plt.bar(x=['left', 'down', 'right'], height=[counter[0], counter[1], counter[2]], label='left_down_right_frequency', color='steelblue', alpha=0.8)
#     plt.title("left_down_right_frequency")
#     plt.show()
#
#     dis_l, dis_d, dis_r = [],[],[]
#     for lane in lanes_info:
#         if lane[0] == 0:
#             dis_l.append(int(float(lane[-1])))
#         elif lane[0] == 1:
#             dis_d.append(int(float(lane[-1])))
#         elif lane[0] == 2:
#             dis_r.append(int(float(lane[-1])))
#     plt.hist(dis_l, 50, facecolor='blue', alpha=0.5)
#     plt.title("distance of left")
#     plt.show()
#     plt.hist(dis_d, 60, facecolor='blue', alpha=0.5)
#     plt.title("distance of down")
#     plt.show()
#     plt.hist(dis_r, 60, facecolor='blue', alpha=0.5)
#     plt.title("distance of right")
#     plt.show()
#
#     angles = []
#     for lane in lanes_info:
#         if lane[0] == 0 or lane[0] == 2:
#             angles.append(lane[2])
#     counter = Counter(angles)
#     plt.bar(x=['3', '4', '5'], height=[counter[3], counter[4], counter[5]], label='left_down_right_frequency', color='steelblue', alpha=0.8)
#     plt.title("angles frequency")
#     plt.show()

# gap = [4,4,4,4,4,6,6,6,6,11,11,12,12]
# start = 360
# output = []
# for g in gap:
#     output.append(start)
#     start -= g
# for g in gap[::-1]:
#     output.append(start)
#     start -= g
# output.append(start)
# print(output)

import os
loss = []
with open('../det-20190805-211143/log.txt') as file:
    for line in file:
        line = line.split('|')[-1]
        if line.startswith(' Average loss: '):
            loss.append(float(line.strip()[-6:]))

plt.plot(range(len(loss)), loss)
plt.show()

import numpy as np
import cv2
curve = {"lanes": [[-2, -2, -2, -2, 632, 625, 617, 609, 601, 594, 586, 578, 570, 563, 555, 547, 539, 532, 524, 516, 508, 501, 493, 485, 477, 469, 462, 454, 446, 438, 431, 423, 415, 407, 400, 392, 384, 376, 369, 361, 353, 345, 338, 330, 322, 314, 307, 299], [-2, -2, -2, -2, 719, 734, 748, 762, 777, 791, 805, 820, 834, 848, 863, 877, 891, 906, 920, 934, 949, 963, 978, 992, 1006, 1021, 1035, 1049, 1064, 1078, 1092, 1107, 1121, 1135, 1150, 1164, 1178, 1193, 1207, 1221, 1236, 1250, 1265, -2, -2, -2, -2, -2], [-2, -2, -2, -2, -2, 532, 503, 474, 445, 416, 387, 358, 329, 300, 271, 241, 212, 183, 154, 125, 96, 67, 38, 9, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], [-2, -2, -2, 781, 822, 862, 903, 944, 984, 1025, 1066, 1107, 1147, 1188, 1229, 1269, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2]], "h_samples": [240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510, 520, 530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670, 680, 690, 700, 710], "raw_file": "clips/0313-1/6040/20.jpg", "run_time": 20, "poly_params": [[-0.0007490195849774594, 0.04801345164633508, 0.4660409005249273], [-0.00011062192107513767, -0.020858596992042733, 0.5695067741417277], [-0.0028246980217723466, 0.12772983455234116, 0.3673634221909625], [0.001013433584937072, -0.10457649566360844, 0.6928532720714268]]}

print(curve['poly_params'])
print(curve['raw_file'])
data_path = '/home/share/samples/tusimple/'
img = cv2.imread(os.path.join(data_path, curve['raw_file']))
# img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# img = img[..., np.newaxis]
# img = np.concatenate((img, img, img), axis=2)
plt.imshow(img)
plt.show()

h, w = 720, 1280
img = np.zeros((h, w), np.uint8)
ys = np.arange(0, w, 10) / w
for a, b, c in curve['poly_params']:
    xs = a*ys**2 + b*ys + c

    for x, y in zip(xs, ys):
        print(x*w, y*h)
        cv2.circle(img, (int(y*h), int(x*w)), radius=2, color=(255, 0, 255), thickness=-1)
plt.imshow(img, cmap='gray')
plt.show()