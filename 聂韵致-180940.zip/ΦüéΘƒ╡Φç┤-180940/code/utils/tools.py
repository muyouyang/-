import time
import numpy as np

kl = np.array([72, 60, 49, 39, 30, 22, 15]).astype(np.float32) / 180 * np.pi
kr = np.array([108, 120, 131, 141, 150, 158, 165]).astype(np.float32) / 180 * np.pi
kd = np.array([165, 150, 141, 131, 120, 108, 100, 90, 80, 72, 60, 49, 39, 30, 15]).astype(np.float32) / 180 * np.pi

def line_to_coord(lanes, h_samples):
    """
    Transforms line into coordinates
    """
    coords = []
    for lane in lanes:# 保存所有的车道线坐标
        lane_coord = []
        assert len(lane) == len(h_samples)
        for x, y in zip(lane, h_samples):
            if x > 0:
                lane_coord.append([x, y])

        if len(lane_coord) > 0:
            coords.append(np.array(lane_coord, dtype=np.float))

    return coords  # include #lane coordinates numpy array with shape (#points_in_lane, 2)


def coord_affine(coord, matrix):
    """
    Map original coordinates into homogeneous coordinates and progress affine transformation
    :param coord: 
    :param matrix: 
    :return: 
    """
    homogeneous_coord = np.transpose(np.array([coord[0], coord[1], 1]))# 齐次坐标
    new_coord = np.matmul(matrix, homogeneous_coord)

    return new_coord


def find_intersection_point(h_samples, coords, width):
    """
    Given old lane coordinates, find new coords which is the intersection between slicing lines and lane
    :param h_samples: no need to explain
    :param coords: numpy array, contains coordinates of each point in a SINGLE lane
    :return:
        lanes: list, the same format as in tusimple dataset
    """
    def find_nearest_neighbor(num, l):
        """
        Find nearest neighbor of num in l, where l is a one dimension iterable object like list or 1-D numpy array
        :param num: number
        :param l: the y coordinates of given coordinates
        :return:
            index
        """
        if num < min(l):
            return -2
        if num > max(l):
            return -1
        for i in range(len(l)-1):
            if l[i] <= num <= l[i+1]:
                return i
        return -2

    lane = [-2]
    # iteration through slice lines
    for slice_idx in range(1, len(h_samples)):
        slc = h_samples[slice_idx]
        idx = find_nearest_neighbor(slc, coords[:, 1])
        if idx >= 0:
            x1, y1 = coords[idx, :]
            x2, y2 = coords[idx+1, :]
            x = (x2 - x1) / (y2 - y1) * (slc - y1) + x1
            if 0 < x < width:
                lane.append(x)
            else:
                lane.append(-2)
        elif idx == -1 and len(coords) > 1:  # extend a few bottom points
            x1, y1 = coords[-2, :]
            x2, y2 = coords[-1, :]
            x = (x2 - x1) / (y2 - y1) * (slc - y1) + x1
            if 0 < x < width:  # x lies in image area
                lane.append(x)
            else:
                lane.append(-2)
        else:
            lane.append(-2)

    assert len(lane) == len(h_samples)

    return lane


def left_proposal_distance(lane, h_samples, start_point, slope):
    """
    Calculate distance between given lane and line proposal
    :param lane: horizontal ordinate of current lane
    :param h_samples: balabala
    :param start_point: start point of line proposal
    :param slope: - tangent of angle of line proposal, -tan(theta)
    :return:
    """
    # find start index and end index of lane
    start_idx, end_idx = 0, len(lane) - 1
    for i in range(len(lane) - 1):
        if lane[i] == -2 and lane[i + 1] > 0:
            start_idx = i + 1
        if lane[i] > 0 and lane[i + 1] == -2:
            end_idx = i

    # Calculate distance between line proposal and lane
    dist = 0
    offset = []
    # if e^c >= s^c
    if h_samples[start_idx] <= start_point:
        end_point = min(h_samples[end_idx], start_point)
        for y_idx in range(start_idx, end_point//4 + 1):
            x = (h_samples[y_idx] - start_point) / slope
            dist += abs(lane[y_idx] - x)
            offset.append(lane[y_idx] - x)
        dist /= len(offset)
    else:
        dist = float('inf')
    offset.reverse()

    return dist, offset


def right_proposal_distance(args, lane, h_samples, start_point, slope):
    # find start index and end index of lane
    start_idx, end_idx = 0, len(lane) - 1
    for i in range(len(lane) - 1):
        if lane[i] == -2 and lane[i + 1] > 0:
            start_idx = i + 1
        if lane[i] > 0 and lane[i + 1] == -2:
            end_idx = i

    dist = 0
    offset = []
    if h_samples[start_idx] <= start_point:
        end_point = min(h_samples[end_idx], start_point)
        for y_idx in range(start_idx, end_point//4 + 1):
            x = (h_samples[y_idx] - start_point) / slope + args.width
            dist += abs(lane[y_idx] - x)
            offset.append(lane[y_idx] - x)
        dist /= len(offset)
    else:
        dist = float('inf')
    offset.reverse()

    return dist, offset


def bottom_proposal_distance(args, lane, h_samples, start_point, slope):
    # find start index and end index of lane
    start_idx, end_idx = 0, len(lane) - 1
    for i in range(len(lane) - 1):
        if lane[i] == -2 and lane[i + 1] > 0:
            start_idx = i + 1
        if lane[i] > 0 and lane[i + 1] == -2:
            end_idx = i

    dist = 0
    offset = []
    for y_idx in range(start_idx, end_idx + 1):
        x = (h_samples[y_idx] - args.height) / slope + start_point
        dist += abs(lane[y_idx] - x)
        offset.append(lane[y_idx] - x)
    dist /= len(offset)
    offset.reverse()

    return dist, offset


def calc_distance(args, lane, h_samples):
    """
    Calculate distance between given lane and all 18*kl+18*kr+30*kd = 666 line proposal
    :param args: lalala
    :param lane: given lane, format as tusimple dataset
    :param h_samples: balala
    """

    # size of output feature map after downsample
    downsample_rate = 16
    down_h = args.height // downsample_rate  # 18
    down_w = args.width // downsample_rate  # 32

    all_dist = []
    all_offset = []

    # calculate left line proposal distance
    for start_point in range(down_h):
        for line_proposal_angle in kl:
            dist, offset = left_proposal_distance(lane, h_samples,
                                                  start_point=start_point * downsample_rate,
                                                  slope=-np.tan(line_proposal_angle))
            all_dist.append(dist)
            all_offset.append(offset)

    # calculate right line proposal distance
    for start_point in range(down_h):
        for line_proposal_angle in kr:
            dist, offset = right_proposal_distance(args, lane, h_samples,
                                                   start_point=start_point * downsample_rate,
                                                   slope=-np.tan(line_proposal_angle))
            all_dist.append(dist)
            all_offset.append(offset)

    # calculate bottom line proposal distance
    for start_point in range(1, down_w - 1):
        for line_proposal_angle in kd:
            dist, offset = bottom_proposal_distance(args, lane, h_samples,
                                                    start_point=start_point * downsample_rate,
                                                    slope=-np.tan(line_proposal_angle))
            all_dist.append(dist)
            all_offset.append(offset)

    """DEBUG"""
    # print(len(all_offset))
    # print(len(all_dist))

    return all_dist, all_offset


class ProgressBar(object):
    def __init__(self):
        self.start_time = None
        self.iter_per_sec = 0
        self.time = None

    def click(self, current_idx, max_idx, total_length=10, front='', end=''):
        """
        Each click is a draw procedure of progressbar
        :param current_idx: range from 0 to max_idx-1
        :param max_idx: maximum iteration
        :param total_length: length of progressbar
        :param front: str, what's shown in front of progressbar
        :param end: str, what's shown at the end of progressbar
        """
        if self.start_time is None:
            self.start_time = time.time()
        else:
            self.time = time.time()-self.start_time
            self.iter_per_sec = 1/self.time
            perc = current_idx * total_length // max_idx
            # print progress bar
            print('\r%s|' % front+'='*perc+'>'+' '*(total_length-1-perc)+'| %d/%d (%.2f iter/s) %s' % (current_idx+1,
                                                                                                       max_idx,
                                                                                                       self.iter_per_sec, end), end='')
            self.start_time = time.time()
        if current_idx+1 == max_idx:
            print('')

    def close(self):
        self.__init__()
        print('')


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.sum += val*n
        self.count += n
        self.avg = self.sum / self.count

def cal_distance(lane1, lane2):
    intersect_mask = (lane1 != 0) & (lane2 != 0)
    lane1 = lane1[intersect_mask]
    lane2 = lane2[intersect_mask]
    distance = np.sum(np.abs(lane1 - lane2)) / (np.sum(intersect_mask) + 1e-8)
    return distance

    # lane1 = lane1[25:]
    # lane2 = lane2[25:]
    # lane1_end_point = np.nonzero(lane1 > 20)[0][-1]
    # lane2_end_point = np.nonzero(lane2 > 20)[0][-1]
    # end_point = min(lane1_end_point, lane2_end_point)
    # lane1 = lane1[:end_point]
    # lane2 = lane2[:end_point]
    # distance = np.sum(np.abs(lane1 - lane2)) / (72-25)
    # return distance

# (ldr_index, angle, feature_index, classification_score, lane)
def NMS(lane_infos, args):
    # for i in range(len(lane_infos)):
    #     lane_infos[i][-1][:start_index] = 0
    lane_infos.sort(key=lambda x: x[3], reverse=True)
    k = 0
    while k < (len(lane_infos) - 1):
        pop_list = []
        for i in range(k + 1, len(lane_infos)):
            if cal_distance(lane_infos[k][-1], lane_infos[i][-1]) <= (args.tneg + 5):
                pop_list.append(i)
        for pop_i in pop_list[::-1]:
            lane_infos.pop(pop_i)
        k += 1
    return lane_infos