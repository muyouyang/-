# -*- coding: utf-8 -*-
import os
import json
import cv2
import torch
import random
import numpy as np
from torch.utils.data import DataLoader, Dataset
from .tools import line_to_coord, coord_affine, find_intersection_point, NMS, kl, kr, kd

MEAN = np.array([0.485, 0.456, 0.406])
STD = np.array([0.229, 0.224, 0.225])

class UISEEDataset(Dataset):
    def __init__(self, args):
        self.data_path = '/home/wxy/data/hkia/hkia_samples'
        # clips = ['1492626286076989589_0','1492627068602933406_0','1492626838739876007_0','1492626861725776049_0','1492626126171818168_0','1492626153155598528_0']
        # self.data_path = '/home/share/samples/tusimple/clips/0530/'+clips[10-5]
        # self.files = os.listdir(self.data_path)
        self.files = [file for file in os.listdir(self.data_path) if file.endswith('.tiff')]
        self.files.sort()
        self.files = [file_name for i, file_name in enumerate(self.files) if i % 5 == 0]
        self.args = args

    def __getitem__(self, item):
        img_path = self.files[item]
        img = cv2.imread(os.path.join(self.data_path, img_path))
        h, w = self.args.height, self.args.width
        img = cv2.resize(img, (w, h))
        coords = np.array([])
        sample = {'img': img, 'coords': coords}
        mean = MEAN.reshape((3, 1, 1))
        var = STD.reshape((3, 1, 1))
        # # /255，再进行标准化
        sample['img'] = torch.Tensor((sample['img'].transpose(2, 0, 1) / 255 - mean) / var)
        # sample['img'] = torch.Tensor((sample['img']))
        return sample

    def __len__(self):
        return len(self.files)


class TuSimpleDataset(Dataset):
    def __init__(self, args, phase='train', transform=None):
        """
        Initialization
        :param args: argument parser
        :param phase: str, phase of dataset, 'train' or 'test'
        :param transform: optional, transform to be applied on input images
        """
        self.args = args
        # root = os.path.join(args.root, 'train_clips')  # all json files store here
        self.transform = transform
        self.phase = phase
        self.files = []

        # read json files
        keyword = 'label' if phase == 'train' else phase
        if keyword == 'label':
            for file in os.listdir(args.root):
                if os.path.isfile(os.path.join(args.root, file)) and keyword in file:# 是满足条件的json文件
                    print(file)
                    self.files.extend([json.loads(line) for line in open(os.path.join(args.root, file)).readlines()])
        else:
            self.files.extend([json.loads(line) for line in open(os.path.join(args.root, 'test_gt.json')).readlines()])


    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        img_path = self.files[idx]['raw_file']
        lanes = self.files[idx]['lanes']
        h_samples = self.files[idx]['h_samples']

        # image reshape
        h, w = self.args.height, self.args.width
        img = cv2.imread(os.path.join(self.args.root, img_path))

        # 将图片变为三层相同的灰度图
        # img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # img = img[..., np.newaxis]
        # img = np.concatenate((img, img, img), axis=2)

        ori_h, ori_w, _ = img.shape
        img = cv2.resize(img, (w, h))

        # lane coordinate transformation
        coords = line_to_coord(lanes, h_samples)
        for lane_idx in range(len(coords)):
            coords[lane_idx] *= np.array([w / ori_w, h / ori_h])# 将车道线也resize

        # package sample
        sample = {'img': img, 'coords': coords, 'filename': img_path}

        # augmentations，数据增强
        if self.transform:
            sample = self.transform(sample)

        # image transpose and normalization
        mean = MEAN.reshape((3, 1, 1))
        var = STD.reshape((3, 1, 1))
        # /255，再进行标准化
        sample['img'] = torch.Tensor((sample['img'].transpose(2, 0, 1) / 255 - mean) / var)
        # sample['img'] = torch.Tensor((sample['img']))
        return sample


class RandomShift(object):
    """
    Randomly shifting image and lane on x, y axis
    """
    def __init__(self, args):
        self.x_offset = args.offsetx
        # self.x_offset = 50
        self.y_offset = args.offsety
        # self.y_offset = 20

    def __call__(self, sample):
        img = sample['img']
        coords = sample['coords']

        # generate offset
        offset_x = random.randint(-self.x_offset, self.x_offset)
        offset_y = random.randint(-self.y_offset, self.y_offset)

        # image shift
        m = np.float32([[1, 0, offset_x], [0, 1, offset_y]])
        img = cv2.warpAffine(img, m, (img.shape[1], img.shape[0]))

        # coordinate shift
        for lane_idx in range(len(coords)):
            coords[lane_idx] += np.array([offset_x, offset_y])

        """DEBUG"""
        # img = np.array(img)
        # for lane in coords:
        #     cv2.polylines(img, np.int32([lane]), isClosed=False, color=(0, 255, 0), thickness=2)
        # cv2.imwrite('random_shift.jpg', img)

        return {'img': img, 'coords': coords}


class RandomHorizontalFlip(object):
    """
    Randomly horizontal flip image and lane with probability p
    """
    def __init__(self, args):
        self.p = args.prob

    def __call__(self, sample):
        img = sample['img']
        coords = sample['coords']
        # lanes = sample['lanes']
        # h_samples = sample['h_samples']

        rand = random.uniform(0, 1)
        if rand > self.p:
            # image flip
            # m = np.float32([[-1, 0, img.shape[1]], [0, 1, 0]])
            # img = cv2.warpAffine(img, m, (img.shape[1], img.shape[0]))
            img = cv2.flip(img, 1)

            for lane_idx in range(len(coords)):
                coords[lane_idx][:, 0] = img.shape[1] - 1 - coords[lane_idx][:, 0]

            """DEBUG"""
            # for lane in coords:
            #     cv2.polylines(img, np.int32([lane]), isClosed=False, color=(0, 255, 0), thickness=2)
            # cv2.imwrite('random_flip.jpg', img)

        return {'img': img, 'coords': coords}


class RandomRotateScale(object):
    """
    Randomly rotate image and line in a random degree between (-args.rotate, args.rotate) and randomly scale them
    """
    def __init__(self, args):
        self.angle = args.rotate
        self.max_scale = args.max_scale
        self.min_scale = args.min_scale

    def __call__(self, sample):
        img = sample['img']
        coords = sample['coords']

        # generate random rotate and scale parameter
        angle = random.randint(-self.angle, self.angle)
        scale = random.uniform(self.min_scale, self.max_scale)

        # generate rotation matrix
        m = cv2.getRotationMatrix2D((img.shape[1] // 2, img.shape[0] // 2), angle, scale)

        # let's transform !
        img = cv2.warpAffine(img, m, (img.shape[1], img.shape[0]))
        for lane_idx in range(len(coords)):
            for coord_idx in range(coords[lane_idx].shape[0]):
                coords[lane_idx][coord_idx, :] = coord_affine(coords[lane_idx][coord_idx, :], m)# 对lane每个点进行变换

        """DEBUG"""
        # for lane in coords:
        #     cv2.polylines(img, np.int32([lane]), isClosed=False, color=(0, 255, 0), thickness=2)
        # cv2.imwrite('random_rotate_scale.jpg', img)

        return {'img': img, 'coords': coords}


class PostProcess(object):
    """
    Generate new h_samples and lanes according to given lane coordinates
    这里主要是因为进行数据增强后，标签中每一个偏移的间隔将不会再保持为4，需要重新再求72条水平线与增强后标签的交点
    """
    def __init__(self, args):
        self.s = args.slice
        self.args = args

    def __call__(self, sample):
        img = sample['img']
        coords = sample['coords']

        dist = img.shape[0] // self.s  # distance between sliced horizontal line
        h_samples = np.arange(0, img.shape[0], dist)  # h_samples can be generated automatically
        lanes = []
        # dist_mat = []
        # offset_mat = []
        # iteration through slicing lines
        for lane_idx in range(len(coords)):
            lane = find_intersection_point(h_samples, coords[lane_idx], img.shape[1])# resize
            lanes.append(lane)

        #     lane_dist, lane_offset = calc_distance(self.args, lane, h_samples)
        #     dist_mat.append(lane_dist)
        #     offset_mat.append(lane_offset)
        #
        # # generate label map
        # dist_mat = np.array(dist_mat)
        # label_map = np.zeros(dist_mat.shape)
        # # distance < threshold will be positive
        # label_map[dist_mat < self.args.tpos] = 1
        # # has the smallest distance to a lane will be positive
        # for s in range(label_map.shape[0]):
        #     if label_map[s, :].sum() == 0:  # all line proposal has big distance between current lane
        #         min_idx = dist_mat[s, :].argmin()
        #         label_map[s, min_idx] = 1
        # # distance > threshold will be negative
        # for line_proposal_idx in range(label_map.shape[1]):
        #     if dist_mat[:, line_proposal_idx].min() > self.args.tneg and 1 not in label_map[:, line_proposal_idx]:
        #         label_map[:, line_proposal_idx] = -1

        """DEBUG"""
        # gt_lanes = [[(x, y) for x, y in zip(lane, h_samples) if x >= 0] for lane in lanes]
        # for lane in gt_lanes:
        #     cv2.polylines(img, np.int32([lane]), isClosed=False, color=(0, 255, 0), thickness=2)
        # cv2.imwrite('regenerated_lane.jpg', img)

        # # visualize lane and positive samples
        # img_black = np.zeros(img.shape)
        # for lane_idx in range(len(lanes)):
        #     lane_coord = [(x, y) for x, y in zip(lanes[lane_idx], h_samples) if x >= 0]
        #     for pt in lane_coord:
        #         cv2.circle(img_black, tuple(np.int32(pt)), radius=2, color=(255, 255, 255))
        #     # find positive line proposal and plot circle
        #     for idx in range(label_map.shape[1]):
        #         if label_map[lane_idx, idx] == 1:
        #             if idx < 18*len(kl):
        #                 start_point = (0, idx // len(kl) * 16)
        #                 slope = -np.tan(kl[idx % len(kl)])
        #             elif idx < 18*(len(kl) + len(kr)):
        #                 start_point = (self.args.width, (idx-18*len(kl)) // len(kr) * 16)
        #                 slope = -np.tan(kr[idx % len(kr)])
        #             else:
        #                 start_point = (((idx-18*len(kl)-18*len(kr)) // len(kd) + 1) * 16, self.args.height)
        #                 slope = -np.tan(kd[(idx-18*len(kl)-18*len(kr)) % len(kd)])
        #             # plot with start point and slope
        #             for y in h_samples:
        #                 x = (y - start_point[1]) / slope + start_point[0]
        #                 cv2.circle(img_black, (int(x), int(y)), radius=1, color=(0, 255, 0))
        # cv2.imshow('1', img_black)
        # cv2.waitKey(0)
        # cv2.imwrite('positive_line_proposal.jpg', img_black)

        return {'img': img, 'coords': lanes}#'label_map': label_map, 'offsets': offset_mat}


def collect_fn(batch):
    """min_scale
    Collect batch data into a dictionary
    :param batch: list, contains a batch of dictionary
    :return:
        a dictionary contains batch information
        given input image with shape (C, H, W), the output batch will be:
            img: tensor, shape (N, C, H, W)
            coords: list, each element is a tensor indicates coordinates of current lane with shape (#coords, 2)
    """
    imgs = []
    if 'coords' in batch[0]:
        coords = []
        for b in batch:
            imgs.append(b['img'])
            lanes = []
            for lane in b['coords']:# 存在样本全为0的情况
                if max(lane) > 0:
                    lanes.append(lane)
            coords.append(lanes)  # shape (#lanes in current img, length)
        return {'img': torch.stack(imgs, dim=0), 'coords': coords}

    elif 'lanes' in batch[0]:
        lanes = []
        h_samples = []
        for b in batch:
            imgs.append(b['img'])
            lanes.append(b['lanes'])
            h_samples.append(b['h_samples'])
        return {'img': torch.stack(imgs, dim=0), 'lanes': lanes, 'h_samples': h_samples}

    else:
        label_maps = []
        offsets = []
        for b in batch:
            imgs.append(b['img'])
            label_maps.append(b['label_map'])
            offsets.append(b['offsets'])
        return {'img': torch.stack(imgs, dim=0), 'label_mapshow-50291.html': label_maps, 'offsets': offsets}

# def collect_fn_eval(batch):
#     imgs = []
#     coords = []
#     for b in batch:
#         imgs.append(b['img'])
#         # if len(b['coords'][0][0]) > 1:# 测试集包含两列
#         #     lanes = b['coords']
#         # else:
#         coords.append(b['coords'])  # shape (#lanes in current img, length)
#     return {'img': torch.stack(imgs, dim=0), 'coords': coords}
