import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from utils.tools import kl, kr, kd
import cv2

"""
为每一个边生成所有的anchor，需要执行三次，但是整个训练过程只需给出一次。
函数里的运算，包括直线坐标，都进行了转换，在新的坐标系中进行（新坐标原点在图像左下角）。
"""
def generate_anchor_x_shift(K, k_index, args):
    S = args.slice
    H = args.height
    W = args.width

    k_angle = K[k_index]
    anchor_y = (np.arange(0, H, args.downsampling_ratio) + args.downsampling_ratio/2.).reshape(-1, 1)# gap16, shape(18,1)
    slicing_line_y = np.arange(0, H, H/S).reshape(1, -1)# gap4, shape(1,72)
    if k_index == 0:
        anchor_x_shift = np.expand_dims((anchor_y - slicing_line_y), axis=-1) / np.tan(k_angle).reshape(1, 1, -1)
    elif k_index == 1:
        anchor_x = (np.arange(args.downsampling_ratio, W-args.downsampling_ratio, args.downsampling_ratio) + args.downsampling_ratio/2.).reshape(-1, 1)
        b = -1. * (np.tan(k_angle).reshape(1, 1, -1) * np.expand_dims(anchor_x, axis=-1))
        anchor_x_shift = (np.expand_dims((H - slicing_line_y), axis=-1) - b) / np.tan(k_angle).reshape(1, 1, -1)
    elif k_index == 2:
        b = np.expand_dims((H - anchor_y), axis=-1) - np.tan(k_angle).reshape(1, 1, -1) * W
        anchor_x_shift = (np.expand_dims((H - slicing_line_y), axis=-1) - b) / np.tan(k_angle).reshape(1, 1, -1)
    anchor_x_shift = np.clip(anchor_x_shift, 0., W*1.0)# 将超出图像的偏移进行clip
    anchor_x_shift[anchor_x_shift == W] = 0
    return anchor_x_shift

'''
将一条车道线与左、下、右中某一个anchor_x_shift进行对比
:return: 
    Distance:anchor中每一条射线与line的偏移，每个位置是一个向量
    DLl:anchor中每一条射线与line的平均偏移量，每个位置是一个标量
    S - E_l:有效偏移量的长度，论文中的Length
'''
def line2line_metric(anchor_x_shift, label_line, args):
    nonzero_index_l = np.nonzero(np.where(label_line > 0, np.ones(label_line.shape), np.zeros(label_line.shape)))
    E_l, S_l = nonzero_index_l[0][0], nonzero_index_l[0][-1]
    S_l = S_l+1
    anchor_x_shift_bool = np.where(anchor_x_shift > 0, np.ones(anchor_x_shift.shape), np.zeros(anchor_x_shift.shape))
    nonzero_index_E = anchor_x_shift_bool.argmax(axis=1)
    nonzero_count = np.count_nonzero(anchor_x_shift_bool, axis=1)
    nonzero_index_S = nonzero_index_E + nonzero_count
    S_c = np.min((np.ones_like(nonzero_index_S) * S_l, nonzero_index_S), axis=0)
    E_c = np.ones_like(nonzero_index_E) * E_l
    Distance = np.zeros_like(anchor_x_shift)
    Regression_r = np.zeros_like(anchor_x_shift)
    for i in range(Distance.shape[0]):
        for j in range(Distance.shape[2]):
            # print(i, j, label_line[E_l:S_l].shape, anchor_x_shift[i, E_l:S_l, j].shape, E_l, S_l)
            Distance[i, E_l:S_c[i, j], j] = label_line[E_l:S_c[i, j]] - anchor_x_shift[i, E_l:S_c[i, j], j]
            Regression_r[i, E_l:S_l, j] = label_line[E_l:S_l] - anchor_x_shift[i, E_l:S_l, j]
    interval = (S_c - E_c) + 1e-10# 有效间隔
    # D_sum = np.sum(Distance, axis=1)
    DLl = np.sum(np.abs(Distance), axis=1) / interval
    return Regression_r, DLl, S_l - E_l# the length of lane label

'''
挑选正负样本，对每一条线，以及每一个边界进行选择。
'''
def choice_pos_neg_anchor(anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r, lanes, args):
    t_pos = args.tpos
    t_neg = args.tneg

    pos_anchor_y_angle_indexs = []# 存储pos标签的index
    mid_anchor_y_angle_indexs = []# 存储mid标签的index
    supplement = []# 存储每一个lane在三个feature中最小的距离

    distance_Ll = [[], [], []]

    for i, lane in enumerate(lanes):
        # lane = np.concatenate(([0] * 16, np.clip(np.array(lane), 0, 1e10))) / 2.5# 标签跟随图片进行resize
        lane = np.clip(np.array(lane), 0, 1e10)

        for j, anchor_x_shift in enumerate([anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r]):
            # 返回单条车道线与所有anchor的距离信息
            Distance, DLl, Length = line2line_metric(anchor_x_shift, lane, args)
            # 确定距离小于15的正样本index
            pos_anchor_y_index, pos_anchor_angle_index = np.nonzero(np.where((DLl < t_pos) & (DLl > 0), 1, 0))
            # 确定距离大于15小于20的中间样本index
            mid_anchor_y_index, mid_anchor_angle_index = np.nonzero(np.where((DLl < t_neg) & (DLl >= t_pos), 1, 0))

            DLl[DLl == 0] = 1e10
            # 记录距离最近的anchor，因为有些离最近的anchor距离大于15
            min_index_x, min_index_y = np.nonzero(np.where(DLl == DLl.min(), 1, 0))
            # i:第几根车道线 j:左下右哪一个
            supplement.append((i, j, min_index_x[0], min_index_y[0], DLl[min_index_x[0], min_index_y[0]], (Length, Distance[min_index_x[0], :, min_index_y[0]])))

            if pos_anchor_y_index.shape[0] != 0:
                for item in [(i, j, y, angle) for y, angle in zip(list(pos_anchor_y_index), list(pos_anchor_angle_index))]:
                    item = (item[0], item[1], item[2], item[3], (Length, Distance[item[2], :, item[3]]))
                    pos_anchor_y_angle_indexs.append(item)
            if mid_anchor_y_index.shape[0] != 0:
                for item in [(i, j, y, angle) for y, angle in zip(list(mid_anchor_y_index), list(mid_anchor_angle_index))]:
                    item = (item[0], item[1], item[2], item[3], (Length, Distance[item[2], :, item[3]]))
                    mid_anchor_y_angle_indexs.append(item)

    # 对离最近的anchor距离大于15的车道线进行补录
    set_a = list(range(len(lanes)))
    set_b = [i for i, _, _, _, _ in pos_anchor_y_angle_indexs]
    difference = list(set(set_a).difference(set(set_b)))# 在pos阈值内没有相应的proposel
    # print(difference)
    for lane_index in difference:
        supplement_lane_index = []
        for supp in supplement:
            if supp[0] == lane_index:
                supplement_lane_index.append(supp)
        supplement_lane_index.sort(key=lambda x: x[4])# 对平均距离进行排序，挑选距离最近的
        # print(supplement_lane_index[0][:5])
        # with open(file, 'a+') as f:
        #     f.write(str(supplement_lane_index[0][:5]) + '\n')
        pos_anchor_y_angle_indexs.append((supplement_lane_index[0][0], supplement_lane_index[0][1], supplement_lane_index[0][2], supplement_lane_index[0][3], supplement_lane_index[0][5]))
    return pos_anchor_y_angle_indexs, mid_anchor_y_angle_indexs

'''
生成正负样本的tensor
anchor: pred
satr: gt
'''
def merge_anchor_feature(x_l, x_d, x_r, pos_anchor_y_angle_indexs, mid_anchor_y_angle_indexs, args):
    all_S = 2 + 1 + args.slice
    K_length = [len(kl), len(kd), len(kr)]

    pos_anchor_index = [[], [], []]
    mid_anchor_index = [[], [], []]
    neg_anchor_index = [[], [], []]
    dict_L_D = {}
    for _, j, y, angle, L_D in mid_anchor_y_angle_indexs:
        mid_anchor_index[j].append((y, angle))
    for _, j, y, angle, L_D in pos_anchor_y_angle_indexs:
        pos_anchor_index[j].append((y, angle))
        dict_L_D[(j, y, angle)] = L_D# Length and Distance

    # left
    pos_anchor_index_0 = list(set(pos_anchor_index[0]))# 去重
    r_pos_stars_l = []# gt
    r_pos_anchor_l = torch.tensor([]).cuda(args.gpu_id)# pre

    r_neg_stars_l = []# gt
    r_neg_anchor_l = torch.tensor([]).cuda(args.gpu_id)# pre

    # 组织左侧正样本的预测和真实的分类、长度、偏移，长度为2+1+72
    for y, angle in pos_anchor_index_0:
        r_star = np.zeros(all_S)
        r_star[:2] = [1, 0]
        L_D = dict_L_D[(0, y, angle)]
        r_star[2] = L_D[0]
        r_star[3:] = L_D[1]
        r_pos_stars_l.append(r_star)
        r_pos_anchor_l = torch.cat((r_pos_anchor_l, (x_l[angle*all_S:(angle + 1)*all_S, y, :]).view(1, -1)), 0)

    # 组织左侧负样本的预测和真实的分类、长度、偏移
    # 每一次负样本的个数都小于等于6
    for _ in range(6):# len(pos_anchor_index_0)*pos_neg_rate
        random_h = np.random.randint(x_l.shape[1])
        random_angle = np.random.randint(K_length[0])
        if (random_h, random_angle) in pos_anchor_index[0] or (random_h, random_angle) in mid_anchor_index[0] or (random_h, random_angle) in neg_anchor_index[0]:
            continue
        neg_anchor_index[0].append((random_h, random_angle))
        r_star = np.zeros(2)
        r_star[:2] = [0, 1]

        r_neg_stars_l.append(r_star)
        r_neg_anchor_l = torch.cat((r_neg_anchor_l, (x_l[random_angle*all_S:random_angle*all_S+2, random_h, :]).view(1, -1)), 0)

    r_pos_stars_l = torch.from_numpy(np.array(r_pos_stars_l)).cuda(args.gpu_id)
    r_neg_stars_l = torch.from_numpy(np.array(r_neg_stars_l)).cuda(args.gpu_id)
    # print(r_pos_stars_l)
    # print(r_pos_anchor_l)
    # print(r_neg_stars_l)
    # print(r_neg_anchor_l)

    # down
    pos_anchor_index_1 = list(set(pos_anchor_index[1]))#去重
    r_pos_stars_d = []
    r_pos_anchor_d = torch.tensor([]).cuda(args.gpu_id)

    r_neg_stars_d = []
    r_neg_anchor_d = torch.tensor([]).cuda(args.gpu_id)

    for y, angle in pos_anchor_index_1:
        r_star = np.zeros(all_S)
        r_star[:2] = [1, 0]
        L_D = dict_L_D[(1, y, angle)]
        r_star[2] = L_D[0]
        r_star[3:] = L_D[1]
        r_pos_stars_d.append(r_star)
        r_pos_anchor_d = torch.cat((r_pos_anchor_d, (x_d[angle * all_S:(angle + 1) * all_S, :, y]).view(1, -1)), 0)

    for _ in range(15):
        random_h = np.random.randint(x_d.shape[-1])
        random_angle = np.random.randint(K_length[1])
        if (random_h, random_angle) in pos_anchor_index[1] or (random_h, random_angle) in mid_anchor_index[1] or (random_h, random_angle) in neg_anchor_index[1]:
            continue
        neg_anchor_index[1].append((random_h, random_angle))
        r_star = np.zeros(2)
        r_star[:2] = [0, 1]

        r_neg_stars_d.append(r_star)
        r_neg_anchor_d = torch.cat((r_neg_anchor_d, (x_d[random_angle*all_S:random_angle*all_S+2, :, random_h]).view(1, -1)), 0)

    r_pos_stars_d = torch.from_numpy(np.array(r_pos_stars_d)).cuda(args.gpu_id)
    r_neg_stars_d = torch.from_numpy(np.array(r_neg_stars_d)).cuda(args.gpu_id)

    # print(r_pos_stars_d)
    # print(r_pos_anchor_d)
    # print(r_pos_stars_d.dtype)
    # print(r_neg_stars_d)
    # print(r_neg_anchor_d)

    # right
    pos_anchor_index_2 = list(set(pos_anchor_index[2]))#去重
    r_pos_stars_r = []
    r_pos_anchor_r = torch.tensor([]).cuda(args.gpu_id)

    r_neg_stars_r = []
    r_neg_anchor_r = torch.tensor([]).cuda(args.gpu_id)

    for y, angle in pos_anchor_index_2:
        r_star = np.zeros(all_S)
        r_star[:2] = [1, 0]
        L_D = dict_L_D[(2, y, angle)]
        r_star[2] = L_D[0]
        r_star[3:] = L_D[1]
        r_pos_stars_r.append(r_star)
        r_pos_anchor_r = torch.cat((r_pos_anchor_r, (x_r[angle*all_S:(angle + 1)*all_S, y, :]).view(1, -1)), 0)

    for _ in range(6):
        random_h = np.random.randint(x_r.shape[1])
        random_angle = np.random.randint(K_length[2])
        if (random_h, random_angle) in pos_anchor_index[2] or (random_h, random_angle) in mid_anchor_index[2] or (random_h, random_angle) in neg_anchor_index[2]:
            continue
        neg_anchor_index[2].append((random_h, random_angle))
        r_star = np.zeros(2)
        r_star[:2] = [0, 1]

        r_neg_stars_r.append(r_star)
        r_neg_anchor_r = torch.cat((r_neg_anchor_r, (x_r[random_angle*all_S:random_angle*all_S+2, random_h, :]).view(1, -1)), 0)

    r_pos_stars_r = torch.from_numpy(np.array(r_pos_stars_r)).cuda(args.gpu_id)
    r_neg_stars_r = torch.from_numpy(np.array(r_neg_stars_r)).cuda(args.gpu_id)
    # print(r_pos_stars_r)
    # print(r_pos_anchor_r)
    # print(r_neg_stars_r)
    # print(r_neg_anchor_r)

    label_anchor_feature = [
        r_pos_stars_l.float(), r_pos_anchor_l, r_neg_stars_l.float(), r_neg_anchor_l,
        r_pos_stars_d.float(), r_pos_anchor_d, r_neg_stars_d.float(), r_neg_anchor_d,
        r_pos_stars_r.float(), r_pos_anchor_r, r_neg_stars_r.float(), r_neg_anchor_r
    ]
    return label_anchor_feature, pos_anchor_index, neg_anchor_index

'''
取相应的featrue，组成分类和回归的loss。
'''
def cal_Loss(anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r, lanes_batch, x_l, x_d, x_r, args):
    gt_cla_feature = torch.tensor([]).cuda(args.gpu_id)
    pre_cla_feature = torch.tensor([]).cuda(args.gpu_id)
    gt_reg_feature = torch.tensor([]).cuda(args.gpu_id)
    pre_reg_feature = torch.tensor([]).cuda(args.gpu_id)

    for i, lanes in enumerate(lanes_batch):
        # 确定正样本和中间样本的y和angle的index
        pos_anchor_y_angle_indexs, mid_anchor_y_angle_indexs = choice_pos_neg_anchor(anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r, lanes, args)
        # 生成正负样本的tensor
        label_anchor_feature, _, _ = merge_anchor_feature(x_l[i, ...], x_d[i, ...], x_r[i, ...], pos_anchor_y_angle_indexs, mid_anchor_y_angle_indexs, args)
        r_pos_stars_l, r_pos_anchor_l, r_neg_stars_l, r_neg_anchor_l, \
        r_pos_stars_d, r_pos_anchor_d, r_neg_stars_d, r_neg_anchor_d, \
        r_pos_stars_r, r_pos_anchor_r, r_neg_stars_r, r_neg_anchor_r = label_anchor_feature

        # 将分类和回归的gt和网络预测的部分进行分离，正样本的分类与负样本的分类部分拼接，正样本的分类与负样本的回归部分拼接
        for tensor in [r_pos_stars_l, r_neg_stars_l, r_pos_stars_d, r_neg_stars_d, r_pos_stars_r, r_neg_stars_r]:# 1,3,5
            if tensor.shape[0] == 0:
                continue
            else:
                if tensor.shape[1] == 75:
                    gt_cla_feature = torch.cat((gt_cla_feature, tensor[:, :2]), 0)
                else:
                    gt_cla_feature = torch.cat((gt_cla_feature, tensor), 0)

        for tensor in [r_pos_anchor_l, r_neg_anchor_l, r_pos_anchor_d, r_neg_anchor_d, r_pos_anchor_r, r_neg_anchor_r]:
            if tensor.shape[0] == 0:
                continue
            else:
                if tensor.shape[1] == 75:
                    pre_cla_feature = torch.cat((pre_cla_feature, tensor[:, :2]), 0)
                else:
                    pre_cla_feature = torch.cat((pre_cla_feature, tensor), 0)

        # for tensor in [r_pos_stars_l, r_pos_stars_d, r_pos_stars_r]:
        #     if tensor.shape[0] == 0:
        #         continue
        #     else:
        #         gt_reg_feature = torch.cat((gt_reg_feature, tensor[:, 2:]), 0)
        #
        # for tensor in [r_pos_anchor_l, r_pos_anchor_d, r_pos_anchor_r]:
        #     if tensor.shape[0] == 0:
        #         continue
        #     else:
        #         pre_reg_feature = torch.cat((pre_reg_feature, tensor[:, 2:]), 0)

        for tensor_gt, tensor_pre in zip([r_pos_stars_l, r_pos_stars_d, r_pos_stars_r], [r_pos_anchor_l, r_pos_anchor_d, r_pos_anchor_r]):
            if tensor_gt.shape[0] == 0:# tensor_pre.shape[0] == 0
                continue
            else:
                gt_reg_feature = torch.cat((gt_reg_feature, torch.masked_select(tensor_gt, tensor_gt != 0)))
                pre_reg_feature = torch.cat((pre_reg_feature, torch.masked_select(tensor_pre, tensor_gt != 0)))

    pre_cla_feature = F.log_softmax(pre_cla_feature, dim=1)
    log_criterion = nn.NLLLoss()
    reg_criterion = nn.SmoothL1Loss()
    # print(pre_cla_feature.shape, gt_cla_feature[:, 0].shape)
    log_loss = log_criterion(pre_cla_feature, gt_cla_feature[:, 0].long())
    reg_loss = reg_criterion(pre_reg_feature, gt_reg_feature)

    return log_loss, reg_loss

if __name__ == '__main__':
    import matplotlib.pyplot as plt
    # torch.Size([1, 450, 18, 1]) torch.Size([1, 1125, 1, 30]) torch.Size([1, 450, 18, 1])
    x_l = torch.randn([2, 450, 18, 1]).cuda(1)
    x_d = torch.randn([2, 1125, 1, 30]).cuda(1)
    x_r = torch.randn([2, 450, 18, 1]).cuda(1)

    H, W = 288, 512
    h, w = 18, 32
    S = 72

    kl = np.array([72, 60, 49, 39, 30, 22]).astype(np.float32) / 180 * np.pi
    kr = np.array([108, 120, 131, 141, 150, 158]).astype(np.float32) / 180 * np.pi
    kd = np.array([165, 150, 141, 131, 120, 108, 100, 90, 80, 72, 60, 49, 39, 30, 15]).astype(np.float32) / 180 * np.pi
    K = [kl, kd, kr]

    from train import args
    anchor_x_shift_l = generate_anchor_x_shift(K, 0, args)# (18, 72, 6)
    anchor_x_shift_d = generate_anchor_x_shift(K, 1, args)# (30, 72, 15)
    anchor_x_shift_r = generate_anchor_x_shift(K, 2, args)# (18, 72, 6)

    dict1 = {"lanes": [[-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 565, 530, 494, 459, 423, 388, 352, 317, 281, 246, 210, 175, 139, 104, 68, 33, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
                      [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 625, 609, 592, 575, 559, 542, 526, 509, 492, 476, 459, 443, 426, 410, 393, 376, 360, 343, 327, 310, 293, 277, 260, 244, 227, 210, 194, 177, 161, 144, 127, 111, 94, 78, 61, 45, 28, -2, -2, -2, -2, -2, -2, -2, -2, -2],
                      [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 672, 690, 712, 734, 757, 779, 801, 824, 846, 869, 891, 913, 936, 958, 981, 1003, 1025, 1048, 1070, 1093, 1115, 1138, 1160, 1182, 1205, 1227, 1250, 1272, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2]],
            "h_samples": [160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510, 520, 530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670, 680, 690, 700, 710],
            "raw_file": "clips/0601/1495058713562969635/20.jpg"}
    dict = {"lanes": [[-2, -2, -2, -2, -2, 627, 615, 600, 585, 566, 545, 524, 503, 471, 439, 407, 375, 342, 310, 278, 246, 214, 181, 149, 117, 85, 52, 20, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
                       [-2, -2, -2, -2, -2, 655, 653, 651, 642, 634, 625, 616, 607, 598, 589, 581, 572, 563, 554, 545, 537, 528, 519, 510, 501, 493, 484, 475, 466, 457, 449, 440, 431, 422, 413, 405, 396, 387, 378, 370, 361, 352, 343, 334, 326, 317, 308, 299, 290, 282, 273, 264, 255, 246, 238, 229],
                       [-2, -2, -2, -2, -2, 681, 680, 680, 680, 679, 682, 696, 709, 722, 736, 749, 762, 775, 789, 802, 815, 829, 842, 855, 869, 882, 895, 908, 922, 935, 948, 962, 975, 988, 1002, 1015, 1028, 1041, 1055, 1068, 1081, 1095, 1108, 1121, 1135, 1148, 1161, 1174, 1188, 1201, 1214, 1228, 1241, 1254, 1268, -2],
                       [-2, -2, -2, -2, 709, 723, 737, 750, 761, 766, 771, 793, 830, 866, 902, 939, 975, 1011, 1048, 1084, 1120, 1156, 1193, 1229, 1265, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2]],
             "h_samples": [160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510, 520, 530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670, 680, 690, 700, 710],
             "raw_file": "clips/0601/1494453447626445283/20.jpg"}
    dict2 = {"lanes": [[-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 648, 636, 626, 615, 605, 595, 585, 575, 565, 554, 545, 536, 526, 517, 508, 498, 489, 480, 470, 461, 452, 442, 433, 424, 414, 405, 396, 386, 377, 368, 359, 349, 340, 331, 321, 312, 303, 293, 284, 275, 265, 256, 247, 237, 228, 219],
                      [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 681, 692, 704, 716, 728, 741, 754, 768, 781, 794, 807, 820, 834, 847, 860, 873, 886, 900, 913, 926, 939, 952, 966, 979, 992, 1005, 1018, 1032, 1045, 1058, 1071, 1084, 1098, 1111, 1124, 1137, 1150, 1164, 1177, 1190, 1203, 1216, 1230, 1243, 1256, 1269],
                      [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 713, 746, 778, 811, 845, 880, 916, 951, 986, 1022, 1057, 1092, 1128, 1163, 1198, 1234, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
                      [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 754, 806, 858, 909, 961, 1013, 1064, 1114, 1164, 1213, 1263, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2]],
             "h_samples": [160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330,
                           340, 350, 360, 370, 380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510,
                           520, 530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670, 680, 690,
                           700, 710],
             "raw_file": "clips/0601/1495058713562969635/20.jpg"}
    # dict2 = {"lanes": [[-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 208, 158, 107, 55, 4, -2, -2, -2, -2, -2, -2, -2, -2,
    #   -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
    #  [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 425, 428, 418, 392, 367, 341, 315, 289, 260, 228, 195, 163, 130, 98,
    #   65, 33, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2,
    #   -2, -2, -2],
    #  [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 497, 519, 532, 532, 531, 528, 519, 511, 503, 495, 487, 479, 469, 459,
    #   449, 438, 428, 417, 407, 396, 386, 376, 365, 355, 344, 334, 323, 313, 302, 292, 282, 271, 261, 250, 240, 229, 219,
    #   209, 198, 188, 177, 167, 156, 146, 136],
    #  [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 578, 616, 652, 678, 704, 718, 731, 745, 758, 769, 781, 792, 804, 816,
    #   827, 839, 850, 862, 873, 885, 897, 908, 920, 931, 943, 954, 966, 978, 989, 1001, 1012, 1024, 1035, 1047, 1059,
    #   1070, 1082, 1093, 1105, 1116, 1128, 1140, 1151, 1163, -2]],
    #          "h_samples": [160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330,
    #                        340, 350, 360, 370, 380, 390, 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 500, 510,
    #                        520, 530, 540, 550, 560, 570, 580, 590, 600, 610, 620, 630, 640, 650, 660, 670, 680, 690,
    #                        700, 710],
    #          "raw_file": "clips/0601/1495058713562969635/20.jpg"}

    lanes_batch = [dict2["lanes"]]
    cal_Loss(anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r, lanes_batch, x_l, x_d, x_r, args)
    # input()

    # # DEBUG 画出正负anchor
    pos_index = [[], [(2, 12), (4, 11), (5, 11)], [(16, 4), (11, 5), (10, 5)]]
    neg_index = [[], [], []]

    img = np.zeros((H, W, 3))
    slicing_line_y = np.arange(0, H, H / S)
    for i, anchor_x_shift in enumerate([anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r]):
        for y, angle_index in pos_index[i]:
            # print(y,angle_index)
            xs = anchor_x_shift[y, :, angle_index]
            for x, y in zip(xs, slicing_line_y):
                cv2.circle(img, (int(x), int(y)), 1, (255, 0, 255), 1)
        for y, angle_index in neg_index[i]:
            xs = anchor_x_shift[y, :, angle_index]
            for x, y in zip(xs, slicing_line_y):
                cv2.circle(img, (int(x), int(y)), 1, (0, 255, 0), -1)

    for lane in dict2["lanes"]:
        for x, y in zip(lane, slicing_line_y[16:]):
            cv2.circle(img, (int(x/2.5), int(y)), 2, (255, 255, 0), 1)
    plt.imshow(img)
    plt.show()

    # # DEBUG 画出在给定阈值范围内，满足条件的anchor
    # slicing_line_y = np.arange(0, H, H/S)
    # img = np.zeros((H, W, 3))
    # lanes = dict2["lanes"]
    # for lane in lanes:
    #     # lane = lanes[1]
    #     lane = np.clip(np.array(lane), 0, 1e10)
    #     lane = np.concatenate(([0]*16, lane)) / 2.5
    #     threshold = 15
    #     # choice_pos_neg_anchor(anchor_x_shift_l, lane)
    #     # choice_pos_neg_anchor(anchor_x_shift_d, lane)
    #     # choice_pos_neg_anchor(anchor_x_shift_r, lane)
    #     for color, anchor_x_shift in zip([[0, 255, 255], [255, 0, 255], [255, 255, 0]], [anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r]):
    #         Distance, DLl, _ = line2line_metric(anchor_x_shift, lane, args)
    #         x_anchors, y_anchors = np.nonzero(np.where((DLl < threshold) & (DLl > 0), 1, 0))
    #         print(x_anchors, y_anchors)
    #         for x, y in zip(x_anchors, y_anchors):
    #             xs = anchor_x_shift[x, :, y]
    #             for x, y in zip(xs, slicing_line_y):
    #                 cv2.circle(img, (int(x), int(y)), 1, color, -1)
    # plt.imshow(img)
    # plt.show()


    # # DEDUB draw anchor
    # img = np.zeros((H, W, 3))
    # # img = cv2.imread('test1.png')
    # slicing_line_y = np.arange(0,  H, H/S)
    #
    # # for y_index in range(0, 18, 4):
    # for angle_index in range(6):
    #     xs = anchor_x_shift_r[9, :, angle_index]
    #     for x, y in zip(xs, slicing_line_y):
    #         # print(x, y)
    #         cv2.circle(img, (int(x), int(y)), 1, (255, 255, 255), -1)
    # plt.imshow(img)
    # plt.show()
