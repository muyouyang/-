import sys
import time
import torch
import torch.nn as nn
from torchvision.transforms import transforms
import logging
from argparse import ArgumentParser
import matplotlib.pyplot as plt

from utils.tools import AverageMeter, ProgressBar
from utils.dataset import *
from metric import cal_Loss, generate_anchor_x_shift
from model.backbone import baseline_model
from visualize import Visualizer


parser = ArgumentParser()
# data input arguments
parser.add_argument('--root', type=str, default='/home/share/samples/tusimple', help='root directory of dataset')
parser.add_argument('--height', type=int, default=288, help='input height of images')
parser.add_argument('--width', type=int, default=512, help='input width of images')
parser.add_argument('--batch_size', type=int, default=64, help='batch size of training')# 32, 192
parser.add_argument('--offsetx', type=int, default=50, help='maximum offset on x axis for randomly shifting')
parser.add_argument('--offsety', type=int, default=20, help='maximum offset on y axis for randomly shifting')
parser.add_argument('--prob', type=float, default=0.1, help='probability of horizontal flip')
parser.add_argument('--rotate', type=int, default=6, help='maximum rotate angle of randomly rotating')
parser.add_argument('--max_scale', type=float, default=1.15, help='maximum scale factor of randomly scale')
parser.add_argument('--min_scale', type=float, default=0.85, help='minimum scale factor of randomly scale')

# model arguments
parser.add_argument('--slice', type=int, default=72, help='number of horizontal line slicing images')
parser.add_argument('--nms', type=int, default=15, help='nms threshold')
parser.add_argument('--gpu_id', type=int, default=7, help='gpu device number')
parser.add_argument('--downsampling_ratio', type=int, default=16, help='model down sampling ratio')

# train arguments
parser.add_argument('--ckpt_dir', type=str, default='det-pre', help='directory of checkpoint')
parser.add_argument('--ckpt_name', type=str, default='epoch_.pth.tar', help='name of checkpoint')
parser.add_argument('--lr', type=float, default=0.001, help='initial learning rate')
parser.add_argument('--epoch', type=int, default=4000, help='total epoch for training')
parser.add_argument('--step', type=int, default=2000, help='step for learning rate decay')
parser.add_argument('--momentum', type=float, default=0.9, help='momentum for gradient descent')
parser.add_argument('--decay', type=float, default=0.0002, help='weight decay')
parser.add_argument('--tpos', type=int, default=15, help='threshold for positive line')
parser.add_argument('--tneg', type=int, default=20, help='threshold for negative line')
parser.add_argument('--lamda', type=float, default=10.0, help='lambda for multi-task loss function')
parser.add_argument('--visdom_name', type=str, default='line-cnn-gary', help='visdom env name')

# eval arguments
parser.add_argument('--pos_thres', type=float, default=0.6, help='if p < pos_thres: pos')

# log and save
parser.add_argument('--save', type=str, default=None, help='name of save directory of log and save point')
parser.add_argument('--log_every', type=int, default=10, help='frequency of log steps')
parser.add_argument('--save_every', type=int, default=3, help='frequency of save epochs')

args = parser.parse_args()


def train_one_epoch(net, dataloader, optimizer, loss_bag, vis):
    loss_recorder = AverageMeter()
    pb = ProgressBar()

    total_batch = len(dataloader)
    for idx, batch in enumerate(dataloader):
        img, lanes_batch = batch['img'], batch['coords']
        img = img.cuda(args.gpu_id)

        # inference，前向传播
        x_l, x_d, x_r = net(img)

        # calculate loss，返回损失
        cls_loss, reg_loss = cal_Loss(*loss_bag, lanes_batch, x_l, x_d, x_r, args)
        cur_loss = args.lamda * cls_loss + reg_loss

        # optimize
        optimizer.zero_grad()
        cur_loss.backward()
        optimizer.step()

        # record loss
        loss_recorder.update(cur_loss.item())
        pb.click(idx, total_batch, end='cls_loss: %.5f, reg_loss: %.5f' % (cls_loss.item(), reg_loss.item()))

        vis.plot('batch_loss', cur_loss.item())
        if idx % args.log_every == 0:
            logging.info('Step [%d/%d]: cls_loss: %.5f, reg_loss: %.5f' % (idx + 1, total_batch, cls_loss.item(), reg_loss.item()))

    logging.info('Average loss: %.3f' % loss_recorder.avg)
    vis.plot('avg_loss', loss_recorder.avg)

def save(epoch, net, optimizer):
    save_dict = {'epoch': epoch,
                 'state_dict': net.state_dict(),
                 'optimizer': optimizer
                 }
    has_epoch = int(args.ckpt_name.split('.')[0].split('_')[-1])
    torch.save(save_dict, os.path.join(args.save, 'epoch_%d.pth.tar' % (epoch + 1 + has_epoch)))
    logging.info('Checkpoint saved!')


def train():
    if not torch.cuda.is_available():
        logging.error('no gpu device found')
        sys.exit(1)

    # TODO: define network and loss

    model = baseline_model([len(kl), len(kd), len(kr)], args.slice).cuda(args.gpu_id)

    # if args.ckpt_dir and args.ckpt_name:
    #     ckpt_path = os.path.join(args.ckpt_dir, args.ckpt_name)
    #     if os.path.isfile(ckpt_path):
    #         # 使用之前resnet101训练的参数，进行继续训练，现在的网络是resnet122，较之前新增了多个bottleneck层，所以只更新部分参数
    #         pretrained_dict = torch.load(ckpt_path)['state_dict']
    #         model_dict = model.state_dict()
    #         # 将pretrained_dict里不属于model_dict的键剔除掉
    #         pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
    #         # 更新现有的model_dict
    #         model_dict.update(pretrained_dict)
    #         # 加载我们真正需要的state_dict
    #         model.load_state_dict(model_dict)
    #
    #         # # 继续使用resnet122的参数
    #         # model_dict = torch.load(ckpt_path)
    #         # model.load_state_dict(model_dict['state_dict'])
    #
    #         # # 如果采用多卡训练的参数更新方式
    #         # from collections import OrderedDict
    #         # new_state_dict = OrderedDict()
    #         # for k, v in model_dict['state_dict'].items():
    #         #     if 'module' in k:
    #         #         k = k[7:]
    #         #     new_state_dict[k] = v
    #         # model.load_state_dict(new_state_dict)

    # model = nn.DataParallel(model, device_ids=[1, 2, 3])
    model.train()

    # 计算左，下，右每一个边的所有anchor的x偏移
    anchor_x_shift_l = generate_anchor_x_shift([kl, kd, kr], 0, args)  # (18, 72, 6)
    anchor_x_shift_d = generate_anchor_x_shift([kl, kd, kr], 1, args)  # (30, 72, 15)
    anchor_x_shift_r = generate_anchor_x_shift([kl, kd, kr], 2, args)  # (18, 72, 6)
    loss_bag = [anchor_x_shift_l, anchor_x_shift_d, anchor_x_shift_r]

    # 准备数据集
    dataset = TuSimpleDataset(args, phase='train', transform=transforms.Compose([RandomShift(args),
                                                                                 RandomHorizontalFlip(args),
                                                                                 RandomRotateScale(args),
                                                                                 PostProcess(args)]))
    train_loader = DataLoader(dataset, args.batch_size, shuffle=True, collate_fn=collect_fn, num_workers=4)
    # pre_res_para = model.backbone.parameters()
    # add_res_para = model.layer3_sibing.parameters()
    # add_convl_para =model.conv_l.parameters()

    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.decay)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=args.step)

    vis = Visualizer(args.visdom_name, port=8097)
    """TRAIN"""
    for epoch in range(args.epoch):
        logging.info('-' * 20 + 'Epoch.' + str(epoch+1) + '-' * 20)
        scheduler.step()
        lr = scheduler.get_lr()[0]
        logging.info('learning rate: %f' % lr)

        train_one_epoch(model, train_loader, optimizer, loss_bag, vis)
        if (epoch + 1) % args.save_every == 0:
            save(epoch, model, optimizer)

if __name__ == '__main__':

    if torch.cuda.is_available():
        # os.environ["CUDA_VISIBLE_DEVICES"] = ','.join(map(str, [1, 2, 3]))
        os.environ["CUDA_VISIBLE_DEVICES"] = "%d" % args.gpu_id
    else:
        raise EnvironmentError('GPU not found!')

    if args.save is None:
        args.save = 'det-{}'.format(time.strftime("%Y%m%d-%H%M%S"))
        os.mkdir(args.save)

    log_format = '%(asctime)s | %(message)s'
    logging.basicConfig(filename=os.path.join(args.save, 'log.txt'), filemode='w',
                        level=logging.INFO, format=log_format, datefmt='%m/%d %I:%M:%S %p')
    logging.info('Let\'s roll')

    train()
