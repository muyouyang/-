# -*- coding: utf-8 -*-
from utils.dataset import *
from train import args
import json
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.use('TkAgg')
from metric import generate_anchor_x_shift
from model.backbone import baseline_model
import tqdm
@torch.no_grad()
def eval():
    # 图森的测试集
    dataset = TuSimpleDataset(args, phase='test', transform=None)

    # 明珠数据集，需要其他的数据集都可以修改 UISEEDataset
    # dataset = UISEEDataset(args)

    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)

    # det-20190809-145139保存的是学习率0.001训练出的line-cnn
    # net_dict = torch.load('det-20190805-211143/epoch_1330.pth.tar', map_location='cpu')

    # det-20190809-145139保存的是学习率0.0001训练出的line-cnn，参数是最终参数
    net_dict= torch.load('det-20190809-145139/epoch_1970.pth.tar', map_location='cpu')

    # det-20190810-152812这个是将图森数据集的输入图片转换为灰度后finetune的参数
    # 运行这个需要将TuSimpleDataset中读取图片后将图片变为灰度图的那三行代码取消注释
    # net_dict = torch.load('det-20190810-152812/epoch_1930.pth.tar', map_location='cpu')

    model = baseline_model([len(kl), len(kd), len(kr)], args.slice).cuda(args.gpu_id)
    model.load_state_dict(net_dict['state_dict'])
    model = model.cuda(args.gpu_id)
    model.eval()

    # 计算三个部分anchor的x偏移
    anchor_x_shift_l = generate_anchor_x_shift([kl, kd, kr], 0, args)  # (18, 72, 6)
    anchor_x_shift_d = generate_anchor_x_shift([kl, kd, kr], 1, args)  # (30, 72, 15)
    anchor_x_shift_r = generate_anchor_x_shift([kl, kd, kr], 2, args)  # (18, 72, 6)

    # pred_lanes.json保存着最后的测试集结果，我们需要将其与真实标签通过evaluate.py计算指标
    os.system('rm pred_lanes.json')
    # bad_pic_id = [0, 7, 9, 10, 26, 27, 29, 36, 43, 62, 67, 70, 78, 90, 95, 96, 97, 98, 105, 113, 131, 146, 166, 189, 191, 197, 300, 312, 335, 339, 347, 437, 455, 481, 505, 511, 528, 535, 539, 571, 585, 590, 595, 609, 612, 616, 618, 625, 628, 639, 646, 649, 669, 707, 751, 786, 796, 804, 817, 827, 842, 854, 855, 862, 881, 883, 907, 931, 979, 984, 989, 1005, 1007, 1014, 1015, 1023, 1032, 1033, 1034, 1088, 1091, 1110, 1111, 1124, 1125, 1132, 1141, 1143, 1147, 1151, 1159, 1166, 1195, 1212, 1216, 1217, 1223, 1224, 1236, 1243, 1244, 1273, 1274, 1295, 1308, 1330, 1332, 1339, 1344, 1357, 1373, 1402, 1412, 1413, 1414, 1415, 1418, 1432, 1442, 1444, 1445, 1450, 1460, 1470, 1472, 1476, 1480, 1490, 1495, 1497, 1499, 1502, 1503, 1509, 1512, 1513, 1515, 1516, 1517, 1518, 1523, 1528, 1530, 1532, 1543, 1550, 1555, 1562, 1571, 1572, 1574, 1575, 1576, 1577, 1599, 1603, 1604, 1623, 1644, 1660, 1666, 1674, 1675, 1676, 1677, 1690, 1700, 1702, 1703, 1704, 1706, 1716, 1723, 1725, 1726, 1729, 1731, 1735, 1750, 1768, 1784, 1794, 1832, 1839, 1841, 1842, 1856, 1857, 1864, 1878, 1891, 1896, 1909, 1920, 1928, 1950, 1951, 1952, 1959, 1979, 1980, 1981, 1983, 1993, 2006, 2012, 2013, 2014, 2057, 2066, 2067, 2068, 2072, 2075, 2076, 2079, 2096, 2098, 2109, 2110, 2111, 2114, 2162, 2165, 2170, 2176, 2196, 2199, 2200, 2228, 2332, 2373, 2396, 2407, 2408, 2501, 2566, 2570, 2669, 2755, 2763, 2774, 2775]
    for idx, batch in enumerate(dataloader):
        # if idx not in bad_pic_id:
        #     continue
        # if idx >= 20:
        #     break

        img, lanes_batch = batch['img'], batch['coords']
        # 因为图片是经过标准化的，我们需要将其进行标准化的逆操作，来进行还原
        ori_image = restore_img(img)
        plt.title('pic-NO.' + str(idx))
        plt.imshow(np.array(ori_image, np.uint8))
        plt.show()
        # 在还原后的图片上画上真实标签
        ori_image = draw_gt_label(ori_image, lanes_batch)
        # plt.title('pic-NO.' + str(idx))
        # plt.imshow(np.array(ori_image, np.uint8))
        # plt.show()
        # cv2.imwrite('./temp_image/weekly/ori-' + str(idx) + '.png', ori_image)
        img = img.cuda(args.gpu_id)

        # x_l.shape: torch.Size([1, 450, 18, 1])
        # x_d.shape: torch.Size([1, 1125, 1, 30])
        # x_r.shape: torch.Size([1, 450, 18, 1])
        x_l, x_d, x_r = model(img)

        # 需要将网络预测的feature map进行reshape，这样方便切片操作
        x_l = x_l.squeeze().reshape(kl.shape[0], args.slice + 2 + 1, -1)
        x_d = x_d.squeeze().reshape(kd.shape[0], args.slice + 2 + 1, -1)
        x_r = x_r.squeeze().reshape(kr.shape[0], args.slice + 2 + 1, -1)
        # 对分类进行softmax操作
        x_l[:, :2, :] = F.softmax(x_l[:, :2, :], dim=1)
        x_d[:, :2, :] = F.softmax(x_d[:, :2, :], dim=1)
        x_r[:, :2, :] = F.softmax(x_r[:, :2, :], dim=1)
        #shape[0]:num_angle ;shape[1]:75;shape[3]:18,30,18 anchor cell
        print('pic-NO.', idx)

        # 为NMS作准备
        lane_infos = []
        # 测试时选出大于阈值的anchor，作为正样本，pos_index_l保存着y和角度的index
        pos_index_l = torch.nonzero(x_l[:, 1, :] > args.pos_thres)

        for angle, slice_index in pos_index_l:
            # 取值
            angle = int(angle.cpu().detach().numpy())
            slice_index = int(slice_index.cpu().detach().numpy())
            # 获取anchor的原始x偏移量
            single_anchor_x_shift = anchor_x_shift_l[slice_index, :, angle]
            # 获取预测的偏移差
            single_anchor_shift_diff = x_l[angle, 3:, slice_index].cpu().detach().numpy()
            # 相加，还原真实的x
            lane = single_anchor_x_shift + single_anchor_shift_diff
            # 获取预测的车道线的长度
            length = x_l[angle, 2, slice_index].cpu().detach().numpy()
            # 确定车道线endpoint的index
            end_index = int((args.downsampling_ratio / 2. + slice_index * args.downsampling_ratio) / 4)
            # 对车道线结果进行neglect和extend
            lane, start_index, end_index = expand_lane(lane, length, end_index, args)
            # 将预测的车道线画在图上
            ori_image = draw_pred_lanes(ori_image, lane, start_index, end_index, args)
            # 分类得分
            classification_score = x_l[angle, 1, slice_index].cpu().detach().numpy()
            # 为NMS作准备，将start_index到end_index以外的区域置0
            lane[end_index:] = 0
            lane[:start_index] = 0
            lane_infos.append((0, angle, slice_index, float(classification_score), lane))
            # plt.imshow(np.array(ori_image, np.uint8))
            # plt.show()
            print('l:', slice_index, angle, start_index, end_index, int(length), float(classification_score))

        pos_index_d = torch.nonzero(x_d[:, 1, :] > args.pos_thres)
        for angle, slice_index in pos_index_d:
            angle = int(angle.cpu().detach().numpy())
            slice_index = int(slice_index.cpu().detach().numpy())
            single_anchor_x_shift = anchor_x_shift_d[slice_index, :, angle]
            single_anchor_shift_diff = x_d[angle, 3:, slice_index].cpu().detach().numpy()
            lane = single_anchor_x_shift + single_anchor_shift_diff
            length = x_d[angle, 2, slice_index].cpu().detach().numpy()
            end_index = args.slice
            lane, start_index, end_index = expand_lane(lane, length, end_index, args)
            ori_image = draw_pred_lanes(ori_image, lane, start_index, end_index, args)
            plt.title('pic-NO.' + str(idx))
            plt.imshow(np.array(ori_image, np.uint8))
            plt.show()
            classification_score = x_d[angle, 1, slice_index].cpu().detach().numpy()
            lane[end_index:] = 0
            lane[:start_index] = 0
            lane_infos.append((1, angle, slice_index, float(classification_score), lane))
            # plt.imshow(np.array(ori_image, np.uint8))
            # plt.show()
            print('d:', slice_index, angle, start_index, end_index, int(length), float(classification_score))

        pos_index_r = torch.nonzero(x_r[:, 1, :] > args.pos_thres)
        for angle, slice_index in pos_index_r:
            angle = int(angle.cpu().detach().numpy())
            slice_index = int(slice_index.cpu().detach().numpy())
            single_anchor_x_shift = anchor_x_shift_r[slice_index, :, angle]
            single_anchor_shift_diff = x_r[angle, 3:, slice_index].cpu().detach().numpy()
            lane = single_anchor_x_shift + single_anchor_shift_diff
            length = x_r[angle, 2, slice_index].cpu().detach().numpy()
            end_index = int((args.downsampling_ratio / 2. + slice_index * args.downsampling_ratio) / 4)
            lane, start_index, end_index = expand_lane(lane, length, end_index, args)
            ori_image = draw_pred_lanes(ori_image, lane, start_index, end_index, args)
            plt.title('pic-NO.' + str(idx))
            plt.imshow(np.array(ori_image, np.uint8))
            plt.show()
            classification_score = x_r[angle, 1, slice_index].cpu().detach().numpy()
            lane[end_index:] = 0
            lane[:start_index] = 0
            lane_infos.append((2, angle, slice_index, float(classification_score), lane))
            # plt.imshow(np.array(ori_image, np.uint8))
            # plt.show()
            print('r:', slice_index, angle, start_index, end_index, int(length), float(classification_score))

        # cv2.imwrite('./temp_image/weekly/lanes-' + str(idx) + '.png', ori_image)
        lane_infos = NMS(lane_infos, args)
        for info in lane_infos:
            # 将NMS后的结果画在图中
            ori_image = draw_pred_lanes_after_nms(ori_image, info[-1], args)

        # 将最终结果的图片进行保存
        # cv2.imwrite('./temp_image/HK/hk-%04d.png' % idx, ori_image)

        # 将最终结果的用plt画出来
        plt.title('pic-NO.' + str(idx))
        plt.imshow(np.array(ori_image, np.uint8))
        plt.show()

        # pred_lanes.json保存着最后的测试集结果，我们需要将其与真实标签通过evaluate.py计算指标
        with open('./pred_lanes.json', 'a+') as f:
            dict_json = {}
            dict_lanes = []
            for lane_info in lane_infos:
                lane_info = np.array(lane_info[-1][16:])
                lane_info[lane_info <= 0] = -2
                lane_info[lane_info >= args.width] = args.width*1.0
                lane_info = lane_info * 2.5
                dict_lanes.append(lane_info.tolist())
            dict_json['lanes'] = dict_lanes
            dict_json['raw_file'] = batch['filename'][0]
            dict_json['run_time'] = 0
            f.write(json.dumps(dict_json)+'\n')#,ensure_ascii=False,indent=2 ))

def restore_img(img):
    mean = torch.from_numpy(MEAN.reshape((1, 1, 3))).float()
    var = torch.from_numpy(STD.reshape((1, 1, 3))).float()
    img = img.cpu().squeeze()
    img = ((img.permute(1, 2, 0)*var + mean) * 255)
    img = img[:, :, [2, 1, 0]]
    img = img.contiguous().numpy()
    return img

def draw_pred_lanes(ori_img, lane, start_index, end_index, args):
    slicing_line_y = np.arange(0, args.height, args.height / args.slice)
    for i, (x, y) in enumerate(zip(lane, slicing_line_y)):
        if i < start_index or i >= end_index:
            cv2.circle(ori_img, (int(x), int(y)), radius=2, color=(100, 0, 100), thickness=-1)
        else:
            cv2.circle(ori_img, (int(x), int(y)), radius=2, color=(255, 0, 255), thickness=-1)
    return ori_img

def draw_pred_lanes_after_nms(ori_img, lane, args):
    slicing_line_y = np.arange(0, args.height, args.height / args.slice)
    # count = 0
    # print(lane)
    for i, (x, y) in enumerate(zip(lane, slicing_line_y)):
        if x > 0:# and i >= start_index:
            # count += 1
            cv2.circle(ori_img, (int(x), int(y)), radius=3, color=(255, 255, 0), thickness=1)
    # print(count)
    return ori_img

def draw_gt_label(img, lanes_batch):
    for lanes in lanes_batch:
        for lane in lanes:
            for x, y in lane:
                cv2.circle(img, (int(x), int(y)), radius=4, color=(0, 255, 255), thickness=1)
    return img

def expand_lane(lane, length, end_index, args):
    if end_index != 72:
        # crop
        while lane[end_index-1] < 0 or lane[end_index-1] >= args.width:# 越界
            end_index -= 1
        # extend
        extend_x = (lane[end_index-1] - lane[end_index-4]) / 3.# 平均偏移量
        while lane[end_index-1] >= 0 and lane[end_index-1] < args.width and end_index < 72:
            lane[end_index] = lane[end_index-1] + extend_x
            end_index += 1
        if lane[end_index-1] < 0 or lane[end_index-1] >= args.width:
            end_index -= 1

    start_index = end_index - int(length)
    return lane, start_index, end_index

    # while end_index-1 < 72:
    #     if end_index-1 == 71:
    #         if lane[end_index-1] < 0 or lane[end_index-1] >= args.width:
    #             end_index -= 1
    #         else:
    #             break
    #     else:
    #         # print(end_index)
    #         if lane[end_index-1] < 0 or lane[end_index-1] >= args.width:
    #             end_index -= 1
    #         else:
    #             if lane[end_index] < 0 or lane[end_index] >= args.width:
    #                 break
    #             else:
    #                 lane[end_index] = lane[end_index-1] + (lane[end_index-1] - lane[end_index-2])
    #                 end_index += 1
    # start_index = end_index - int(length)
    # return lane, start_index, end_index

    # print([end_index-2, end_index-1], lane[end_index-2:end_index])
    # for y, x in zip([end_index-2, end_index-1], lane[end_index-2:end_index]):
    #     cv2.circle(ori_image, (int(x), int(y*4)), radius=4, color=(0, 255, 255), thickness=-1)
    # return ori_image

if __name__=='__main__':
    args.gpu_id = 0
    args.pos_thres = 0.9
    os.environ["CUDA_VISIBLE_DEVICES"] = "%d" % args.gpu_id
    eval()